select * from Students;
select StudentID, Name, City from Students where City = 'Kandy';
update Students set City = 'Galle' where StudentID = 4;
select StudentID, Name, City from Students where StudentID = 4;
select s.StudentID, s.Name, s.City, c.Name as CourseName, c.LecturerName from Students s join Courses c on s.CourseID = c.CourseID; 