using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using studentapp.data;
using studentapp.model;

namespace studentapp.Pages
{
    public class AddStudentModel : PageModel
    {
        private readonly StudentContext _context;
        public AddStudentModel(StudentContext context)
        {
            _context = context;
        }
        [BindProperty]
        public Student Student { get; set; }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            // Save student to database
            _context.Students.Add(Student);
            await _context.SaveChangesAsync();

            return RedirectToPage("/StudentInfo"); // Redirect to Student Info page
        }
    }
}
