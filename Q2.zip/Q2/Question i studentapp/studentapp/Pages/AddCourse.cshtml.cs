using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using studentapp.data;
using studentapp.model;

namespace studentapp.Pages
{
    public class AddCourseModel : PageModel
    {
        private readonly StudentContext _context;
        public AddCourseModel(StudentContext context)
        {
            _context = context;
        }
        [BindProperty]
        public Course Course { get; set; }
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            // Save course to database
            _context.Courses.Add(Course);
            await _context.SaveChangesAsync();

            return RedirectToPage("/StudentInfo");
        }
    }
}
