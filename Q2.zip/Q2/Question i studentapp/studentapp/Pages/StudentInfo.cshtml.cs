using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using studentapp.data;
using studentapp.model;

namespace studentapp.Pages
{
    public class StudentInfoModel : PageModel
    {
        private readonly StudentContext _context;

        public StudentInfoModel(StudentContext context)
        {
            _context = context;
        }
        public List<Student> Students { get; set; }


        public async Task OnGetAsync()
        {
            // Load all students with their associated courses
            Students = await _context.Students.Include(s => s.Course).ToListAsync();
        }
    }
}
