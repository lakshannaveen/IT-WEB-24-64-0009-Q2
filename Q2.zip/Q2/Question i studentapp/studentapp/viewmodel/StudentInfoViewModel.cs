﻿using studentapp.model;

namespace studentapp.viewmodel
{
    public class StudentInfoViewModel
    {
        public Student Student { get; set; }
        public Course Course { get; set; }
    }
}
